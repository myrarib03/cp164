"""
-------------------------------------------------------
Tests various linked sorting functions.
-------------------------------------------------------
Author:  David Brown
ID:      999999999
Email:   dbrown@wlu.ca
Section: CP164 C
__updated__ = "2024-07-13"
-------------------------------------------------------
"""
# Imports
import random

from List_linked import List
from Number import Number
from Sorts_List_linked import Sorts

# Constants
SIZE = 100  # Size of array to sort.
XRANGE = 1000  # Range of values in random arrays to sort.
TESTS = 100  # Number of random arrays to generate.

SORTS = (
    ('Bubble Sort', Sorts.bubble_sort),
    ('Insertion Sort', Sorts.insertion_sort),
    ('Merge Sort', Sorts.merge_sort),
    ('Quick Sort', Sorts.quick_sort),
    ('Selection Sort', Sorts.selection_sort),
)


def create_sorted():
    """
    -------------------------------------------------------
    Creates a sorted List of Number objects.
    Use: values = create_sorted()
    -------------------------------------------------------
    Returns:
        values - a sorted list of SIZE Number objects (List of Number)
    -------------------------------------------------------
    """

    # your code here
    values = List()
    for i in range(SIZE):
        numbers = Number(i)
        values.append(numbers)
    return values


def create_reversed():
    """
    -------------------------------------------------------
    Create a reversed List of Number objects.
    Use: values = create_reversed()
    -------------------------------------------------------
    Returns:
        values - a reversed list of SIZE Number objects (List of Number)
    -------------------------------------------------------
    """

    # your code here

    values = List()
    for i in range(SIZE - 1, -1, -1):

        number = Number(i)
        values.append(number)

    return values


def create_randoms():
    """
    -------------------------------------------------------
    Create a 2D list of Number objects with TESTS rows and
    SIZE columns of values between 0 and XRANGE.
    Use: lists = create_randoms()
    -------------------------------------------------------
    Returns:
        lists - TESTS lists of SIZE Number objects containing
            values between 0 and XRANGE (list of List of Number)
    -------------------------------------------------------
    """

    # your code here
    lists = List()
    for __ in range(TESTS):
        rand_list = List()
        for _ in range(SIZE):
            number = Number(random.randint(0, XRANGE))
            rand_list.append(number)
        lists.append(rand_list)
    return lists


def test_sort(title, func):
    """
    -------------------------------------------------------
    Tests a sort function with Number data and prints the number 
    of comparisons necessary to sort an array:
    in order, in reverse order, and a list of Lists in random order.
    Use: test_sort(title, func)
    -------------------------------------------------------
    Parameters:
        title - name of the sorting function to call (str)
        func - the actual sorting function to call (function)
    Returns:
        None
    -------------------------------------------------------
    """
    # Reset comparison and swap counts
    Number.comparisons = 0
    Sorts.swaps = 0

    # Generate different types of lists
    sorted_list = create_sorted()
    reversed_list = create_reversed()
    random_lists = create_randoms()

    # Test on sorted list
    func(sorted_list)
    sorted_comparisons = Number.comparisons
    sorted_swaps = round(Sorts.swaps, 0)
    Number.comparisons = 0
    Sorts.swaps = 0

    # Test on reversed list
    func(reversed_list)
    reversed_comparisons = Number.comparisons
    reversed_swaps = round(Sorts.swaps, 0)
    Number.comparisons = 0
    Sorts.swaps = 0

    # Test on randomized lists
    total_random_comparisons = 0
    total_random_swaps = 0
    for random_list in random_lists:
        func(random_list)
        total_random_comparisons += Number.comparisons
        total_random_swaps += Sorts.swaps
        Number.comparisons = 0
        Sorts.swaps = 0

    avg_random_comparisons = total_random_comparisons // TESTS
    avg_random_swaps = total_random_swaps // TESTS

    # Print the results
    print("{:14} {:8} {:8} {:8} {:8} {:8} {:8}".format(
        title, sorted_comparisons, reversed_comparisons,
        avg_random_comparisons, sorted_swaps,
        reversed_swaps, avg_random_swaps))

    return
