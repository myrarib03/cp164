"""
-------------------------------------------------------
Linked version of the BST ADT.
-------------------------------------------------------
Author:  David Brown
ID:      123456789
Email:   dbrown@wlu.ca
__updated__ = "2024-08-13"
-------------------------------------------------------
"""
# Imports
from copy import deepcopy
from Deque_linked import Deque
from collections import defaultdict, deque


class _BST_Node:

    def __init__(self, value):
        """
        -------------------------------------------------------
        Initializes a BST node containing value. Child pointers 
        are None, height is 1.
        Use: node = _BST_Node(value)
        -------------------------------------------------------
        Parameters:
            value - value for the node (?)
        Returns:
            A _BST_Node object (_BST_Node)            
        -------------------------------------------------------
        """
        self._value = deepcopy(value)
        self._left = None
        self._right = None
        self._height = 1
        self._count = 0

    def _update_height(self):
        """
        -------------------------------------------------------
        Updates the height of the current node.
        Use: node._update_height()
        -------------------------------------------------------
        Returns:
            _height is 1 plus the maximum of the node's two children.
        -------------------------------------------------------
        """
        # your code here
        left_height = self._left._height if self._left is not None else 0
        right_height = self._right._height if self._right is not None else 0
        self._height = 1 + max(left_height, right_height)
        return

    def __str__(self):
        """
        USE FOR TESTING ONLY
        -------------------------------------------------------
        Returns node height and value as a string - for debugging.
        -------------------------------------------------------
        """
        return "h: {}, v: {}".format(self._height, self._value)


class BST:

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty BST.
        Use: bst = BST()
        -------------------------------------------------------
        Returns:
            A BST object (BST)
        -------------------------------------------------------
        """
        self._root = None
        self._count = 0

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if bst is empty.
        Use: b = bst.is_empty()
        -------------------------------------------------------
        Returns:
            True if bst is empty, False otherwise.
        -------------------------------------------------------
        """
        # your code here
        if self._root is None:
            value = True
        else:
            value = False
        return value

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the number of nodes in the BST.
        Use: n = len(bst)
        -------------------------------------------------------
        Returns:
            the number of nodes in the BST.
        -------------------------------------------------------
        """
        # your code here
        return self._count

    def insert(self, value):
        """
        -------------------------------------------------------
        Inserts a copy of value into the bst. Values may appear 
        only once in a tree.
        Use: b = bst.insert(value)
        -------------------------------------------------------
        Parameters:
            value - data to be inserted into the bst (?)
        Returns:
            inserted - True if value is inserted into the BST,
                False otherwise. (boolean)
        -------------------------------------------------------
        """
        # must be done recursively
        # your code here
        self._root, inserted = self._insert_aux(self._root, value)
        return inserted

    def _insert_aux(self, node, value):
        if node is None:
            node = _BST_Node(value)
            inserted = True
            self._count += 1
        elif node is not None:
            if node._value > value:
                node._left, inserted = self._insert_aux(node._left, value)
            elif node._value < value:
                node._right, inserted = self._insert_aux(node._right, value)
            else:
                inserted = False
        if inserted:
            node._update_height()
        return node, inserted

    def retrieve(self, key):
        """
        -------------------------------------------------------
        Retrieves a copy of a value matching key in a BST. (Iterative)
        Use: v = bst.retrieve(key)
        -------------------------------------------------------
        Parameters:
            key - data to search for (?)
        Returns:
            value - value in the node containing key, otherwise None (?)
        -------------------------------------------------------
        """
        # your code here
        value = None
        node = self._root
        while node is not None and value is None:
            if node._value > key:
                node = node._left
            elif node._value < key:
                node = node._right
            elif node._value == key:
                value = deepcopy(node._value)
        return value

    def remove(self, key):
        """
        -------------------------------------------------------
        Removes a node with a value matching key from the bst.
        Returns the value matched. Updates structure of bst as
        required.
        Use: value = bst.remove(key)
        -------------------------------------------------------
        Parameters:
            key - data to search for (?)
        Returns:
            value - value matching key if found, otherwise None.
        -------------------------------------------------------
        """
        if self._root is not None:
            self._root, value = self._remove_aux(self._root, key)
        else:
            value = None
        return value

    def _remove_aux(self, node, key):
        """
        -------------------------------------------------------
        Attempts to find a value matching key in a BST node. Deletes the node
        if found and returns the sub-tree root.
        Private recursive operation called only by remove.
        Use: node, value = self._remove_aux(node, key)
        -------------------------------------------------------
        Parameters:
            node - a bst node to search for key (_BST_Node)
            key - data to search for (?)
        Returns:
            node - the current node or its replacement (_BST_Node)
            value - value in node containing key, None otherwise.
        -------------------------------------------------------
        """
        if node is None:
            # Base Case: the key is not in the tree.
            value = None
        elif key < node._value:
            # Search the left subtree.
            node._left, value = self._remove_aux(node._left, key)
        elif key > node._value:
            # Search the right subtree.
            node._right, value = self._remove_aux(node._right, key)
        else:
            # Value has been found.
            value = node._value
            self._count -= 1
            # Replace this node with another node.
            if node._left is None and node._right is None:
                # node has no children.
                # your code here
                node = None
            elif node._left is None:
                # node has no left child.
                # your code here
                value = node._right
                node._right = None
                node = value
            elif node._right is None:
                # node has no right child.
                # your code here
                value = node._left
                node._left = None
                node = value
            else:
                # Node has two children
                # your code here (calls _delete_node somewhere)
                repl_node = self._delete_node_left(node)
                if repl_node is not None:
                    left = node._left
                    right = node._right
                    node = repl_node
                    node._left = None
                    node._right = None
                    node._left = left
                    node._right = right

            if node is not None and value is not None:
                # If the value was found, update the ancestor heights.
                node._update_height()
        return node, value

    def _delete_node_left(self, parent):
        """
        -------------------------------------------------------
        Finds a replacement node for a node to be removed from the tree.
        Private operation called only by _remove_aux.
        Use: repl_node = self._delete_node_left(node, node._right)
        -------------------------------------------------------
        Parameters:
            parent - node to search for largest value (_BST_Node)
        Returns:
            repl_node - the node that replaces the deleted node. This node 
                is the node with the maximum value in the deleted node's left
                subtree (_BST_Node)
        -------------------------------------------------------
        """
        # your code here

        left = parent._left
        if left is not None:
            right = left._right
            repl_node = right
            while right is not None:
                repl_node = right
                right = right._right
        else:
            right = parent._right
            if right is not None:
                left = right._left
                repl_node = left
                while left is not None:
                    repl_node = left
                    left = left._left
            else:
                repl_node = None
        return repl_node

    def remove_root(self):
        """
        -------------------------------------------------------
        Removes the root node and returns its value.
        Use: value = bst._remove_root()
        -------------------------------------------------------
        Returns:
            value - value in root.
        -------------------------------------------------------
        """
        assert self._root is not None, "Cannot remove the room of an empty BST"
        # your code here
        # missing case for when the right and left values next are both none.
        parent = self._root
        left = parent._left
        if left is not None:
            right = left._right
            repl_node = right
            while right is not None:
                repl_node = right
                right = right._right

            if right is None:
                repl_node = self._root._right
        else:
            repl_node = None

        right_root_value = self._root._right
        left_root_value = self._root._left
        self._root = repl_node
        self._root._right = right_root_value
        self._root._left = left_root_value
        return

    def __contains__(self, key):
        """
        ---------------------------------------------------------
        Determines if the bst contains key.
        Use: b = key in bst
        -------------------------------------------------------
        Parameters:
            key - a comparable data element (?)
        Returns:
            True if the bst contains key, False otherwise.
        -------------------------------------------------------
        """
        # your code here
        node = self._root
        contains = False
        if node is None:
            contains = False
        elif key == node._value and node._left is None and node._right is None:
            contains = True
        elif key > node._value:
            right = node._right
            while right is not None and contains is False:
                if right._value > key:
                    right = right._left
                elif right._value < key:
                    right = right._right
                elif right._value == key:
                    contains = True
        elif key < node._value:
            left = node._left
            while left is not None and contains is False:
                if left._value > key:
                    left = left._left
                elif left._value < key:
                    left = left._right
                elif left._value == key:
                    contains = True
        return contains

    def height(self):
        """
        -------------------------------------------------------
        Returns the maximum height of a BST, i.e. the length of the
        largest path from root to a leaf node in the tree.
        Use: h = bst.height()
        -------------------------------------------------------
        Returns:
            maximum height of bst (int)
        -------------------------------------------------------
        """
        # your code here
        return self._root._height

    def __eq__(self, target):
        """
        ---------------------------------------------------------
        Determines whether two BSTs are equal.
        Values in self and target are compared and if all values are equal
        and in the same location, returns True, otherwise returns False.
        Use: equals = source == target
        ---------------
        Parameters:
            target - a bst (BST)
        Returns:
            equals - True if source contains the same values
                as target in the same location, otherwise False. (boolean)
        -------------------------------------------------------
        """
        equals = True
        if self._count != target._count:
            equals = False
        if self._root is not None and target._root is not None:
            if self._root._value != target._root._value:
                equals = False
            list1 = []
            self._eq_aux(self._root, list1)
            list2 = []
            target._eq_aux(target._root, list2)
            if list1[:] != list2[:]:
                equals = False
        return equals

    def _eq_aux(self, node, lists):
        if node is not None:
            lists.append(node._value)
            self._eq_aux(node._left, lists)
            self._eq_aux(node._right, lists)
        return

    def parent(self, key):
        """
        ---------------------------------------------------------
        Returns the value of the parent node of a key node in a bst.
        ---------------------------------------------------------
        Parameters:
            key - a key value (?)
        Returns:
            value - a copy of the value in a node that is the parent of the
            key node, None if the key is not found. (?)
        ---------------------------------------------------------
        """
        assert self._root is not None, "Cannot locate a parent in an empty BST"
        # your code here
        node1 = self._root
        parent = None
        found = False
        while node1 is not None and found is False:
            if key < node1._value:
                parent = node1
                node1 = node1._left
            elif key > node1._value:
                parent = node1
                node1 = node1._right
            elif key == node1._value:
                found = True

        if found is True and parent is not None:
            value = deepcopy(parent._value)
        else:
            value = None
        return value

    def parent_r(self, key):
        """
        ---------------------------------------------------------
        Returns the value of the parent node in a bst given a key.
        ---------------------------------------------------------
        Parameters:
            key - a key value (?)
        Returns:
            value - a copy of the value in a node that is the parent of the
            key node, None if the key is not found.
        ---------------------------------------------------------
        """
        assert self._root is not None, "Cannot locate a parent in an empty BST"
        # your code here
        parent = None
        node = self._root
        found, parent, node = self.parent_r_aux(key, parent, node, False)
        if found and parent is not None:
            value = deepcopy(parent._value)
        else:
            value = None
        return value

    def parent_r_aux(self, key, parent, node, found):
        if node is None:
            parent = None
            found = False
        elif node._value == key:
            found = True
        elif key < node._value and found is False:
            found, parent, node = self.parent_r_aux(
                key, node, node._left, False)
        elif key > node._value and found is False:
            found, parent, node = self.parent_r_aux(
                key, node, node._right, False)
        return found, parent, node

    def max(self):
        """
        -------------------------------------------------------
        Finds the maximum value in BST. (Iterative algorithm)
        Use: value = bst.max()
        -------------------------------------------------------
        Returns:
            value - a copy of the maximum value in the BST (?)
        -------------------------------------------------------
        """
        assert self._root is not None, "Cannot find maximum of an empty BST"
        # your code here
        maximum = self._root
        while maximum._right is not None:
            maximum = maximum._right
        value = deepcopy(maximum._value)
        return value

    def max_r(self):
        """
        ---------------------------------------------------------
        Returns the largest value in a bst. (Recursive algorithm)
        Use: value = bst.max_r()
        ---------------------------------------------------------
        Returns:
            value - a copy of the maximum value in the BST (?)
        ---------------------------------------------------------
        """
        assert self._root is not None, "Cannot find maximum of an empty BST"
        # your code here
        maximum = self._max_r_aux(self._root)
        return maximum

    def _max_r_aux(self, node):
        if node._left is not None:
            maximum = self._max_r_aux(node._right)
        else:
            maximum = node
        return maximum

    def min(self):
        """
        -------------------------------------------------------
        Finds the minimum value in BST. (Iterative algorithm)
        Use: value = bst.min()
        -------------------------------------------------------
        Returns:
            value - a copy of the minimum value in the BST (?)
        -------------------------------------------------------
        """
        assert self._root is not None, "Cannot find minimum of an empty BST"
        # your code here
        minimum = self._root
        while minimum._left is not None:
            minimum = minimum._left
        value = deepcopy(minimum._value)
        return value

    def min_r(self):
        """
        ---------------------------------------------------------
        Returns the minimum value in a bst. (Recursive algorithm)
        Use: value = bst.min_r()
        ---------------------------------------------------------
        Returns:
            value - a copy of the minimum value in the BST (?)
        ---------------------------------------------------------
        """
        assert self._root is not None, "Cannot find minimum of an empty BST"
        # your code here
        minimum = self._max_r_aux(self._root)
        return minimum

    def _min_r_aux(self, node):
        if node._left is not None:
            minimum = self._max_r_aux(node._left)
        else:
            minimum = node
        return minimum

    def leaf_count(self):
        """
        ---------------------------------------------------------
        Returns the number of leaves (nodes with no children) in bst.
        Use: n = bst.leaf_count()
        (Recursive algorithm)
        ---------------------------------------------------------
        Returns:
            count - number of nodes with no children in bst (int)
        ---------------------------------------------------------
        """
        # your code here
        node = self._root

        count = self._leaf_count_aux(node)
        return count

    def _leaf_count_aux(self, node):
        if node is None:
            count = 0
        elif node._left is None and node._right is None:
            count = 1
        else:
            count = self._leaf_count_aux(
                node._right) + self._leaf_count_aux(node._left)
        return count

    def two_child_count(self):
        """
        ---------------------------------------------------------
        Returns the number of the three types of nodes in a BST.
        Use: count = bst.two_child_count()
        -------------------------------------------------------
        Returns:
            count - number of nodes with two children in bst (int)
        ----------------------------------------------------------
        """
        # your code here
        count = self.two_child_count_aux(self._root, 0)
        return count

    def two_child_count_aux(self, node, count):
        if node is not None:
            if node._right is not None and node._left is not None:
                count += 1
            count = self.two_child_count_aux(node._left, count)
            count = self.two_child_count_aux(node._right, count)
        return count

    def one_child_count(self):
        """
        ---------------------------------------------------------
        Returns the number of the three types of nodes in a BST.
        Use: count = bst.one_child_count()
        -------------------------------------------------------
        Returns:
            count - number of nodes with one child in bst (int)
        ----------------------------------------------------------
        """
        # your code here
        node = self._root
        counts = self._one_child_aux(node)
        return counts

    def _one_child_aux(self, node):
        if node is None:
            count = 0
        elif node._left is None and node._right is None:
            count = 0
        elif node._left is None or node._right is None:
            if node._left is not None and node._left._left is None:
                count = 1
            elif node._left is not None and node._left._left is not None:
                count = 1 + self._one_child_aux(node._left)
            elif node._right is not None and node._right._right is None:
                count = 1
            elif node._right is not None and node._right._right is not None:
                count = 1 + self._one_child_aux(node._right)
        else:
            count = self._one_child_aux(
                node._right) + self._one_child_aux(node._left)
        return count

    def node_counts(self):
        """
        ---------------------------------------------------------
        Returns the number of the three types of nodes in a BST.
        Use: zero, one, two = bst.node_counts()
        -------------------------------------------------------
        Returns:
            zero - number of nodes with zero children (int)
            one - number of nodes with one child (int)
            two - number of nodes with two children (int)
        ----------------------------------------------------------
        """
        # your code here
        zero, one, two = self.node_counts_aux(0, 0, 0, self._root)
        return zero, one, two

    def node_counts_aux(self, zero, one, two, node):
        # needs to be fixed
        if node is not None:

            if node._right is not None and node._left is not None:
                two += 1
            elif node._right is not None and node._left is None or node._right is None and node._left is not None:
                one += 1
            elif node._right is None and node._left is None:
                zero += 1

            zero, one, two = self.node_counts_aux(zero, one, two, node._left)
            zero, one, two = self.node_counts_aux(zero, one, two, node._right)

        return zero, one, two

    def is_balanced(self):
        """
        ---------------------------------------------------------
        Returns whether a bst is balanced, i.e. the difference in
        height between all the bst's node's left and right subtrees is <= 1.
        Use: b = bst.is_balanced()
        ---------------------------------------------------------
        Returns:
            balanced - True if the bst is balanced, False otherwise (boolean)
        ---------------------------------------------------------
        """
        # your code here
        node = self._root
        balanced = True
        if self._root is not None:
            balanced = self.is_balanced_aux(node, balanced)
        return balanced

    def is_balanced_aux(self, node, balanced):
        if node is not None:
            if node._right is None and node._left is not None:
                balanced = False
            elif node._right is not None and node._left is None:
                balanced = False
            else:
                balanced = self.is_balanced_aux(node._right, True)
                if balanced is True:
                    balanced = self.is_balanced_aux(node._left, True)
        return balanced

    def _node_height(self, node):
        """
        ---------------------------------------------------------
        Helper function to determine the height of node - handles empty node.
        Private operation called only by _is_valid_aux.
        Use: h = self._node_height(node)
        ---------------------------------------------------------
        Parameters:
            node - the node to get the height of (_BST_Node)
        Returns:
            height - 0 if node is None, node._height otherwise (int)
        ---------------------------------------------------------
        """
        # your code here
        if node is None:
            height = 0
        else:
            height = node._height
        return height

    def retrieve_r(self, key):
        """
        -------------------------------------------------------
        Retrieves a _value in a BST. (Recursive)
        Use: v = bst.retrieve(key)
        -------------------------------------------------------
        Parameters:
            key - data to search for (?)
        Returns:
            value - If bst contains key, returns value, else returns None.
        -------------------------------------------------------
        """
        # your code here
        value = self._retrieve_r_aux(key, self._root, None)
        return value

    def _retrieve_r_aux(self, key, node, value):
        if node is not None:
            if node._value > key:
                value = self._retrieve_r_aux(key, node._left, value)
            elif node._value < key:
                value = self._retrieve_r_aux(key, node._right, value)
            elif node._value == key:
                value = deepcopy(node._value)
        return value

    def is_valid(self):
        """
        ---------------------------------------------------------
        Determines if a tree is a is_valid BST, i.e. the values in all left nodes
        are smaller than their parent, and the values in all right nodes are
        larger than their parent, and height of any node is 1 + max height of
        its children.
        Use: b = bst.is_valid()
        ---------------------------------------------------------
        Returns:
            valid - True if tree is a BST, False otherwise (boolean)
        ---------------------------------------------------------
        """
        # your code here
        valid = self.is_valid_aux(self._root, True)
        return valid

    def is_valid_aux(self, node, valid):
        if node is not None:
            if node._left is not None and node._left._value > node._value:
                valid = False
            elif node._right is not None and node._right._value < node._value:
                valid = False
            elif node._left is not None and node._right is not None and node._left._height > node._right._height and (self._node_height(node)-1) != self._node_height(node._left):
                valid = False
            elif node._left is not None and node._right is not None and node._right._height > node._left._height and self._node_height(node)-1 != self._node_height(node._right):
                valid = False
            elif node._left is None and node._right is None and node._height != 1:
                valid = False
            else:
                valid = self.is_valid_aux(node._left, True)
                if valid is True:
                    valid = self.is_valid_aux(node._right, valid)
        return valid

    def inorder(self):
        """
        -------------------------------------------------------
        Generates a list of the contents of the tree in inorder order.
        Use: a = bst.inorder()
        -------------------------------------------------------
        Returns:
            a - copy of the contents of the tree in inorder (list of ?)
        -------------------------------------------------------
        """
        # your code here
        a = []
        node = self._root
        self.inorder_aux(node, a)
        return a

    def inorder_aux(self, node, values):
        if node is None:
            return
        self.inorder_aux(node._left, values)
        values.append(node._value)
        self.inorder_aux(node._right, values)

    def preorder(self):
        """
        -------------------------------------------------------
        Generates a list of the contents of the tree in preorder order.
        Use: a = bst.preorder()
        -------------------------------------------------------
        Returns:
            a - copy of the contents of the tree in preorder (list of ?)
        -------------------------------------------------------
        """
        # your code here
        a = []
        if self._root is not None:
            node1 = self._root
            a.append(self._root._value)
            self.preorder_aux(node1, a)
        return a

    def preorder_aux(self, previous, a):
        if previous is not None:
            # this works because it updates the node every time until eventually you only have one node left
            # so it ends up running
            if previous._left is not None:
                a.append(previous._left._value)
                self.preorder_aux(previous._left, a)

            if previous._right is not None:
                a.append(previous._right._value)
                self.preorder_aux(previous._right, a)
        return

    def postorder(self):
        """
        -------------------------------------------------------
        Generates a list of the contents of the tree in postorder order.
        Use: a = bst.postorder()
        -------------------------------------------------------
        Returns:
            a - copy of the contents of the tree in postorder (list of ?)
        -------------------------------------------------------
        """
        # your code here
        a = []
        node = self._root
        self.postorder_aux(node, a)
        return a

    def postorder_aux(self, node, a):
        if node is None:
            return
        self.postorder_aux(node._left, a)
        self.postorder_aux(node._right, a)
        a.append(node._value)

    def levelorder(self):
        """
        -------------------------------------------------------
        Copies the contents of the tree in levelorder order to a list.
        Use: values = bst.levelorder()
        -------------------------------------------------------
        Returns:
            values - a list containing the values of bst in levelorder.
            (list of ?)
        -------------------------------------------------------
        """
        # levelorder is traversed through a BST using other functions
        # this one is done iteratively and not recursively since it
        # is using a level for a BST and not a order
        # like postorder, preorder, and inorder.
        values = []
        new_list = []
        root = self._root

        if root is not None:
            new_list.append(root)

            while len(new_list) > 0:
                node = new_list.pop(0)
                values.append(deepcopy(node._value))
                left = node._left
                right = node._right
                if left is not None:
                    new_list.append(left)
                if right is not None:
                    new_list.append(right)
        return values

    def zigzag_levelorder(self):
        """
        Perform a zigzag level order traversal of a BST, where you alternate the 
        direction of level order traversal between left-to-right and 
        right-to-left as you move down the levels.
        exl/ original reads from  ---->
        then it reads to        <-------
        then it reads to     ------------->
            6
           / \
          3   8
         / \   \
        2   4   9
              \
               7                       
        = [6,8,3,2,4,9,7]
        """
        if not self._root:
            return []

        result = []
        queue = Deque()
        queue.insert_front(self._root)
        left_to_right = True

        while queue:
            level_size = len(queue)
            level_nodes = []

            for _ in range(level_size):
                node = queue.remove_front()
                level_nodes.append(node._value)

                if node._left:
                    queue.insert_rear(node._left)
                if node._right:
                    queue.insert_rear(node._right)

            if not left_to_right:
                level_nodes.reverse()

            result.extend(level_nodes)
            left_to_right = not left_to_right

        return result

    def morris_traversal(self):
        """
        Implement an inorder traversal of a BST without using recursion or a stack.
        Use Morris Traversal, which modifies the tree temporarily to achieve O(1) space complexity.
        """
        current = self._root
        a = []

        while current:
            if current._left is None:
                a.append(current._value)
                current = current._right
            else:
                # Find the inorder predecessor of current
                pre = current._left
                while pre._right and pre._right != current:
                    pre = pre._right
                # Make current as the right child of its inorder predecessor
                if pre._right is None:
                    pre._right = current
                    current = current._left
                # Revert the changes made to restore the original tree and print current node
                else:
                    pre._right = None
                    a.append(current._value)
                    current = current._right
        return a

    def boundary_traversal_interlaced(self):
        """
        this function only returns the leftomost and rightmost values
        of a BST added to a list (a)
        """
        a = []
        current = self._root
        current1 = self._root._left
        current2 = self._root._right
        a.append(current._value)
        self.boundary_traversal_aux(a, current1, current2)
        return a

    def boundary_traversal_aux(self, a, current1, current2):
        if current1 is not None and current2 is not None:
            a.append(current1._value)
            a.append(current2._value)
            self.boundary_traversal_aux(a, current1._left, current2._right)
        elif current1 is None and current2 is not None:
            a.append(current2._value)
            self.boundary_traversal_aux(a, current1, current2._right)
        elif current2 is None and current1 is not None:
            a.append(current1._value)
            self.boundary_traversal_aux(a, current1._left, current2)
        return

    def boundary_traversal(self):
        """
        Perform a boundary traversal of the BST, which includes the nodes on the left boundary,
        all the leaf nodes, and then the nodes on the right boundary.
        left boundary are included
        all leaf nodes are included
        right boundary is included
        """
        a = []
        current = self._root
        current1 = self._root._left
        current2 = self._root._right
        a.append(current._value)
        self.boundary_traversal_aux(a, current1, current2)
        self.add_leaves(a, current)
        return a

    def add_leaves(self, a, current):
        if current is not None:
            if current._left is None and current._right is None and self.max() != current._value and self.min() != current._value:
                a.append(current._value)
            self.add_leaves(a, current._left)
            self.add_leaves(a, current._right)
        return

    def vertical_order_traversal(self):  # ***GO BACK OVER THIS ONE ASAP***
        """
        traverses the list column by column from left to right
        """
        if not self._root:
            return []

        column_table = defaultdict(list)
        queue = deque([(self._root, 0)])  # (node, column index)

        while queue:
            node, column = queue.popleft()
            column_table[column].append(node._value)
            if node._left:
                queue.append((node._left, column - 1))
            if node._right:
                queue.append((node._right, column + 1))
        # Sort by column index and extract the nodes
        sorted_columns = sorted(column_table.keys())
        return [column_table[col] for col in sorted_columns]

    def diagonal_traversal(self):
        """
        Perform a diagonal traversal of a BST, 
        where you traverse the tree diagonally from the root to the bottom right.
        """
        out = []
        node = self._root
        # queue to store left nodes
        left_q = deque()
        while node:
            # append data to output array
            out.append(node._value)
            # if left available add it to the queue
            if node._left:
                left_q.appendleft(node._left)
            # if right is available change the node
            if node._right:
                node = node._right
            else:
                # else pop the left_q
                if len(left_q) >= 1:
                    node = left_q.pop()
                else:
                    node = None
        return out

    def reverse_levelorder(self):
        """
        Perform a spiral order traversal (also known as reverse level order zigzag traversal) 
        of a BST, where you alternate levels but start the alternation in reverse.
        """
        values = []
        new_list = []
        root = self._root

        if root is not None:
            new_list.append(root)
            while len(new_list) > 0:
                # if you remove the pop here and return insert to append for values
                node = new_list.pop(0)
                # you get a different iteration through the BST that may also prove to be helpful
                values.insert(0, deepcopy(node._value))
                left = node._left
                right = node._right
                if left is not None:
                    new_list.append(left)
                if right is not None:
                    new_list.append(right)
        return values

    def reverse_inorder_traversal(self):
        """
        Perform a reverse inorder traversal of the BST (right subtree -> root -> left subtree).
        """
        a = []
        node = self._root
        self.reverse_inorder_aux(node, a)
        return a

    def reverse_inorder_aux(self, node, values):
        if node is None:
            return
        self.inorder_aux(node._right, values)
        values.append(node._value)
        self.inorder_aux(node._left, values)

    def shifted_right(self, node):
        """
        shifts BST nodes a specified number of times to the right based on what the user says
        (same thing as shifting up)
        this is a rotate function that moves things to the right
        """
        if node._value == self._root._value:
            noted = True
        new_root = node._left
        node._left = new_root._right
        new_root._right = node
        if noted is True:
            self._root = new_root
        return new_root

    def shifted_left(self, node):
        """
        shifts BST nodes to the left
        (same thing as shifting down)
        this is a rotate function that moves things to the left
        """
        if node._value == self._root._value:
            noted = True
        new_root = node._right
        node._right = new_root._left
        new_root._left = node
        if noted is True:
            self._root = new_root
        return new_root

    def count(self):
        """
        ---------------------------------------------------------
        Returns the number of nodes in a BST.
        Use: number = bst.count()
        -------------------------------------------------------
        Returns:
            number - count of nodes in tree (int)
        ----------------------------------------------------------
        """
        # try to go iteratively through it without self._count. It may help to calculate all of the nodes.
        # your code here
        return self._count

    def __iter__(self):
        """
        -------------------------------------------------------
        Generates a Python iterator. Iterates through a BST node
        in level order.
        Use: for v in bst:
        -------------------------------------------------------
        Returns:
            yields
            value - the values in the BST node and its children (?)
        -------------------------------------------------------
        """
        if self._root is not None:
            # Put the nodes for one level into a queue.
            queue = []
            queue.append(self._root)

            while len(queue) > 0:
                # Add a copy of the data to the sublist
                node = queue.pop(0)
                yield node._value

                if node._left is not None:
                    queue.append(node._left)
                if node._right is not None:
                    queue.append(node._right)
        return
