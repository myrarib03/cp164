"""
-------------------------------------------------------
Array version of the List ADT.
-------------------------------------------------------
Author: Myra Ribeiro
ID:     169030590
Email:  ribe0590@mylaurier.ca
__updated__ = "2024-07-18"
-------------------------------------------------------
"""
# pylint: disable=E0303
# pylint: disable=E1128
# pylint: disable=E2515
# pylint: disable=W0212
# pylint: disable=W0613

# Imports
from copy import deepcopy


class List:
    """
    Implements an array-based List ADT.
    """

    def rotate_right(self, n):
        """
        -------------------------------------------------------
        Rotates position of elements in self. When finished elements
        in self are rotated n positions to the right.
        n may be positive, negative, or 0
        Use: source.rotate_right(n)
        -------------------------------------------------------
        Parameters:
            n - amount to rotate List elements to the right (int)
        Returns‌​‌​​​​‌​​‌‌​​‌‌​​‌‌‌​‌‌‌‌‌​:
            None
        -------------------------------------------------------
        """

        # your code here
        turns = 0
        #list = [1,2,3]
        #n = 1
        #list = [3,1,2]
        while turns < n:
            value = self._values.pop()  # list = [1,2,3]
            self._values.insert(0, value)
            turns += 1
        return

    def adjacents_count(self):
        """
        -------------------------------------------------------
        Returns the count of the largest number of adjacent values in source.
        Use: count = source.adjacents_count(n)
        -------------------------------------------------------
        Returns‌​‌​​​​‌​​‌‌​​‌‌​​‌‌‌​‌‌‌‌‌​:
            count - the count of the largest number of adjacent values
                in source (int >= 0)
        -------------------------------------------------------
        """

        # your code here
        # determine the largest number of the same values next to eachother in self._values
        # [1,2,2,3,3,3,4]
        new_count = 1
        index = 0
        count = 0
        while index < len(self._values):
            while (index + new_count) < len(self._values) and self._values[index] == self._values[index + new_count]:
                if new_count > count:
                    count = new_count
                new_count += 1
            new_count = 1
            index += 1
        return count

    """
    DO NOT CHANGE CODE BELOW THIS LINE
    =======================================================================
    """

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an empty list.
        Use: source = List()
        -------------------------------------------------------
        Returns‌​‌​​​​‌​​‌‌​​‌‌​​‌‌‌​‌‌‌‌‌​:
            a new List object (List)
        -------------------------------------------------------
        """
        self._values = []

    def append(self, value):
        """
        ---------------------------------------------------------
        Adds a copy of value to the end of source.
        Use: source.append(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (*)
        Returns‌​‌​​​​‌​​‌‌​​‌‌​​‌‌‌​‌‌‌‌‌​:
            None
        -------------------------------------------------------
        """
        self._values = self._values + [deepcopy(value)]
        return

    def __iter__(self):
        """
        USE FOR TESTING ONLY
        -------------------------------------------------------
        Generates a Python iterator. Iterates through source
        from front to rear.
        Use: for v in source:
        -------------------------------------------------------
        Returns‌​‌​​​​‌​​‌‌​​‌‌​​‌‌‌​‌‌‌‌‌​:
            value - the next value in source (*)
        -------------------------------------------------------
        """
        for value in self._values:
            yield value
