"""
-------------------------------------------------------
Queue Functions
-------------------------------------------------------
Author: Myra Ribeiro
ID:     169030590
Email:  ribe0590@mylaurier.ca
__updated__ = "2024-07-21"
-------------------------------------------------------
"""
# pylint: disable=E0303
# pylint: disable=E1128
# pylint: disable=E2515
# pylint: disable=W0212
# pylint: disable=W0613

# Imports
from Queue_array import Queue


def threads_weave(threads):
    """
    -------------------------------------------------------
    Combines multiple Queues into one Queue where the multiple Queue
    values are interwoven into the returned Queue. Values are removed
    from each Queue in threads.
    Use: singleton = threads_weave(threads)
    -------------------------------------------------------
    Parameters:
        threads - a list of Queues to process (list of Queue)
    Returns‌​‌​​​​‌​​‌‌​​‌‌​​‌‌‌​‌‌‌‌‌​:
        singleton - a Queue (Queue)
    -------------------------------------------------------
    """
    # your code here
    # threads = list of queues...
    # 1. get the length of threads to determine
    # how much queues we need to iterate through.
    # lets assume for now that it is three.
    singleton = Queue()
    while any(not q.is_empty() for q in threads):
        for q in threads:
            if not q.is_empty():
                singleton.insert(q.remove())
    return singleton


def queue_rotate(source, n):
    """
    -------------------------------------------------------
    Rotates position of values in source, meaning moving its contents
    from the front to the rear n times.
    Use: queue_rotate(source, n)
    -------------------------------------------------------
    Parameters:
        source - the Queue to rotate (Queue)
        n - amount to rotate Queue values (int)
    Returns‌​‌​​​​‌​​‌‌​​‌‌​​‌‌‌​‌‌‌‌‌​:
        None
    -------------------------------------------------------
    """
    # your code here
    count = 0
    while count < n:
        value = source.remove()
        source.insert(value)
        count += 1
    return
