"""
-------------------------------------------------------
Priority Queue Functions
-------------------------------------------------------
Author: Myra Ribeiro
ID:     169030590
Email:  ribe0590@mylaurier.ca
__updated__ = "2024-07-21"
-------------------------------------------------------
"""
# pylint: disable=E0303
# pylint: disable=E1128
# pylint: disable=E2515
# pylint: disable=W0212
# pylint: disable=W0613

# Imports
from Priority_Queue_array import Priority_Queue


def pq_strip_key(source, key):
    """
    -------------------------------------------------------
    Removes all values from source that have a priority less than key.
    Use: pq_strip_key(source, key)
    -------------------------------------------------------
    Parameters:
        source - a priority queue (Priority_Queue)
        key - a key value (?)
    Returns‌​‌​​​​‌​​‌‌​​‌‌​​‌‌‌​‌‌‌‌‌​:
        None
    -------------------------------------------------------
    """
    filtered_queue = Priority_Queue()
    while not source.is_empty():
        item = source.remove()
        if item < key:
            filtered_queue.insert(item)
    while not filtered_queue.is_empty():
        source.insert(filtered_queue.remove())
    return
