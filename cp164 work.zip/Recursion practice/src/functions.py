"""
-------------------------------------------------------
[Recursion Practice]
-------------------------------------------------------
Author:  Myra Ribeiro
ID:      169030590
Email:   ribe0590@mylaurier.ca
__updated__ = "2024-07-25"
-------------------------------------------------------
"""


def get_factorial(num):
    # calculates the factorial of a number
    # 5! = 5* 4! = 4* 3! = 3* 2! = 2* 1!
    if num == 0:
        factorial = 1
    else:
        factorial = num*get_factorial(num-1)
    return factorial


def calculate_sum(list_num):
    # calculates the sum of a list of numbers using recursion
    # base case
    if len(list_num) == 0:
        total = 0
    else:
        total = list_num.pop() + calculate_sum(list_num)
    return total


def fibonacci(num):
    # calculates the fibonacci sequence using recursion
    if num == 1:
        answer = 0
    elif num == 2:
        answer = 1
    else:
        answer = fibonacci(num-1) + fibonacci(num - 2)
    return answer


def positive_int(num):
    if (num-2) < 0:
        answer = 0
    else:
        answer = num + positive_int(num-2)
    return answer


def harmonic_sum(num):
    if num == 1:
        answer = 1/num
    else:
        answer = (1/num) + harmonic_sum(num-1)
    return answer


def power(a, b):
    if b == 0:
        answer = 1
    elif b == 1:
        answer = a
    else:
        answer = a*power(a, b-1)
    return answer

# recursion with strings


def string_reverse(string):
    if string == "":
        answer = ""
    else:
        answer = string_reverse(string[1:]) + string[0]
    return answer


def list_reverse(items):
    if items == []:
        answer = []
    else:
        # you have to add them both as lists so items[0] needs square brackets around it
        answer = list_reverse(items[1:]) + [items[0]]
    return answer

# this is an example of fruitful recursion as we are returning a specific answer
# an example of in place recursion would be swapping the specific parts of a list but not changing the data structure
# an additional example of recursion would be tree recursion
# tree recursion involves calling multiple recursive calls in one function. for example, fibonacci is tree recursion.
# this is because we call it twice.

# auxilery functions help recursion to work efficiently


def recurse(x, y):
    """
    -------------------------------------------------------
    Recursive function - example of tree recursion.
    Use: ans = recurse(x, y)
    -------------------------------------------------------
    Parameters:
        x - an integer (int)
        y - an integer (int)
    Returns:
        ans - the function result (int)
    -------------------------------------------------------
    if x < 0 or y < 0: f(x,y) = x - y
    otherwise...
    f(x,y) = f(x-1,y) + f(x,y-1)
    """
    if x < 0 or y < 0:
        answer = x-y
    else:
        answer = recurse(x-1, y) + recurse(x, y-1)
    return answer


def gcd(m, n):
    """
    -------------------------------------------------------
    Recursively find the Greatest Common Denominator of two numbers.
    Use: ans = gcd(m, n)
    -------------------------------------------------------
    Parameters:
        n - an integer (int)
        m - an integer (int)
    Returns:
        ans - the function result (int)
    -------------------------------------------------------
    """
    if n == 0 or m == 0:
        answer = 0
    elif n == 1 or m == 1:
        answer = 1
    elif n % m == 0:
        answer = m
    elif m % n == 0:
        answer = n
    else:
        answer = gcd(n, m % n)
    return answer


def vowel_count(s):
    """
    -------------------------------------------------------
    Recursively counts number of vowels in a string.
    Use: count = vowel_count(s)
    -------------------------------------------------------
    Parameters:
        s - string to examine (str)
    Returns:
        count - number of vowels in s (int)
    -------------------------------------------------------
    """

    # when x is 0 is if the entire string has no vowels or is equal to zero
    # when x is one is when there is only one vowel in the string
    s = s.lower()
    if s in ['a', 'e', 'i', 'o', 'u']:
        count = 1
    elif s == '':
        count = 0
    elif len(s) == 1 and s not in ['a', 'e', 'i', 'o', 'u']:
        count = 0
    else:
        count = vowel_count(s[0]) + vowel_count(s[1:])
    return count


def to_power(base, power):
    """
    -------------------------------------------------------
    Calculates base^power.
    Use: ans = to_power(base, power)
    -------------------------------------------------------
    Parameters:
        base - base to apply power to (float)
        power - power to apply (int)
    Returns:
        ans - base ^ power (float)
    -------------------------------------------------------
    """

    if base == 0:
        ans = 0
    elif power == 1:
        ans = base
    elif power == 0:
        ans = 1
    else:
        ans = base*to_power(base, power-1)
    return ans


def is_palindrome(s):
    """
    -------------------------------------------------------
    Recursively determines if s is a palindrome. Ignores non-letters and case.
    Use: palindrome = is_palindrome(s)
    -------------------------------------------------------
    Parameters:
        s - a string (str)
    Returns:
        palindrome - True if s is a palindrome, False otherwise (boolean)
    -------------------------------------------------------
    """
    s = is_palindrome_aux(s)
    s = s.lower()
    if s[::-1] == s:
        palindrome = True
    else:
        palindrome = False
    return palindrome


def is_palindrome_aux(s):
    # loop initalization = string = ''
    # loop condition: iterating through elemnts in the string, if it is an alphabetic character
    # update step = string += i
    # base case: when the string is empty, the characters that are alphabetic is zero
    # recursive case: check if the first element is alphabetic and then add the rest of them throughout the list
    # if they are all alphabetic
    alpha = ''
    if len(s) == 0:
        alpha = ''
    elif len(s) == 1 and s.isalpha():
        alpha = s
    elif len(s) == 1 and not s.isalpha():
        alpha = ''
    else:
        alpha = is_palindrome_aux(s[0]) + is_palindrome_aux(s[1:])
    return alpha


def bag_to_set(bag):
    """
    -------------------------------------------------------
    Copies elements of a bag to a set.
    Use: new_set = bag_to_set(bag)
    -------------------------------------------------------
    Parameters:
        bag - a list of values (list)
    Returns:
        new_set - containing one each of the elements in bag (list)
    -------------------------------------------------------
        new_set = []
    while count < len(bag):
        if bag[count]  not in new_set:
            new_set.append(bag[count])
        count += 1

    new_set = []
    if len(bag) == 0:
        new_set = []
    elif len(bag) == 1 and bag not in new_set:
        new_set = [bag[0]]
    elif len(bag) == 1 and bag in new_set:
        new_set = []
    else:
        new_set = bag_to_set([bag[0]]) + bag_to_set(bag[1:])
    return new_set
    """
    # loop initalization = new_set[]
    # loop condition = iterrating through bag, if i is in new_set we append to new set
    # update step = new_set.append(i)
    # base_case = if our bag is zero
    # recursive case = check if the first element is in new_set if not add to the list. if it is, ignore.)
    new_set = []

    if len(bag) == 0:
        new_set = []

    elif bag[0] not in new_set and len(bag) == 1:
        new_set = bag[0]

    elif bag[0] in new_set and len(bag) == 1:
        new_set = []

    else:
        new_set = [bag[0]] + bag_to_set([bag[2:]])
    return new_set

#bag = [2]
#new_set = [2]
#bag = [2,3]
#new_set = [2,3]
#bag = [2,2]
#new_set = [2]


bag = [1, 2, 2, 3, 4, 4, 5, 6]
print(bag_to_set(bag))
